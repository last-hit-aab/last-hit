export default {
	ROOT: '/*',
	SPLASH: '/splash',
	CREATE_WORKSPACE: '/workspace/create',
	OPENED_WORKSPACE: '/workspace/opened'
};
