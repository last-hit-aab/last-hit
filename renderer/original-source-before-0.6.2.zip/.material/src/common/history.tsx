import * as History from 'history';

export default History.createHashHistory();
